<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Services\TaskService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class TaskController extends Controller
{
    protected $taskService;

    public function __construct(TaskService $taskService)
    {
        $this->taskService = $taskService;
    }

    public function index(Request $request)
    {
        $keyword = $request->input('keyword');
        $tasks = $this->taskService->getTasksByUserId($keyword);
        return response()->json($tasks, 200);
    }

    public function store(Request $request)
    {
        if ($this->validateData($request)->fails()) {
            return response()->json([
                'errors' => $this->validateData($request)->errors()
            ], 422);
        }

        $data = $request->only('title');
        $task = $this->taskService->create($data);
        if (!$task) {
            return response()->json([
                'errors' => "Add failed."
            ], 500);
        }
        return response()->json([
            'status' => true,
            'data' => $task
        ], 201);
    }

    private function validateData(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required|unique:tasks',
        ]);
    }

    public function update(Request $request)
    {
        if ($this->validateDataForUpdate($request)->fails()) {
            return response()->json([
                "errors" => $this->validateDataForUpdate($request)->errors()
            ], 422);
        }

        $data = $request->all();
        $task = $this->taskService->getTaskById($data['id']);
        if (!$task) {
            return response()->json([
                "errors" => "Task not exits!"
            ], 404);
        }

        $this->taskService->checkUserId($task->user_id);

        $updatedResult = $this->taskService->update($data, $task);
        if (!$updatedResult) {
            return response()->json([
                'errors' => "Update failed."
            ], 500);
        }

        return response()->json([
            'status' => true
        ]);
    }

    private function validateDataForUpdate(Request $request)
    {
        $statusArr = array_keys(config('constants.TASK_STATUS'));
        return Validator::make($request->all(), [
            'id' => 'required|integer|min:1',
            'title' => 'required|max:255|unique:tasks,title,' . $request->input('id'),
            'status' => [
                'required',
                Rule::in($statusArr),
            ]
        ]);
    }

    public function destroy($id)
    {
        if (!is_numeric($id) || $id < 1) {
            return response()->json([
                'errors' => 'id invalid.'
            ], 422);
        }

        $task = $this->taskService->getTaskById($id);

        if (!$task) {
            return response()->json([
                "errors" => "Task not exits!"
            ], 404);
        }

        $this->taskService->checkUserId($task->user_id);

        $deleteResult = $task->delete();
        if (!$deleteResult) {
            return response()->json([
                'errors' => "Delete failed."
            ], 500);
        }

        return response()->json([
            'status' => true
        ]);
    }
}
