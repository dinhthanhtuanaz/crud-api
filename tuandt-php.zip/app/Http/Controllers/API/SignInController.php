<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Services\AuthService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SignInController extends Controller
{
    protected $authService;

    public function __construct(AuthService $authService)
    {
        $this->authService = $authService;
    }

    public function main(Request $request)
    {
        if ($this->validateData($request)->fails()) {
            return response()->json([
                'errors' => $this->validateData($request)->errors()
            ], 422);
        }

        $credentinals = $this->getData($request);
        $responseData  = $this->authService->signIn($credentinals);
        if (!$responseData) {
            return response()->json([
                'errors' => "Account not exits!"
            ], 401);
        }

        return response()->json($responseData);
    }

    private function validateData(Request $request)
    {
        $rules = array(
            'email' => 'required|email',
            'password' => 'required|min:5|max:32'
        );
        return Validator::make($request->all(), $rules);
    }

    private function getData(Request $request)
    {
        return $request->only(['email', 'password']);
    }
}
