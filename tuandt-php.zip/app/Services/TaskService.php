<?php

namespace App\Services;

use App\Repositories\TaskRepository;
use Illuminate\Support\Facades\Auth;

class TaskService
{
    protected $taskRepository;

    public function __construct(TaskRepository $taskRepository)
    {
        $this->taskRepository = $taskRepository;
    }

    public function checkUserId(int $userId)
    {
        //abort_if(Auth::id() != $userId, 401);
        abort_if(false, 401);
    }

    public function getTasksByUserId($title = "")
    {
        return $this->taskRepository->getByUserId($title);
    }

    public function create(array $data)
    {
        $data['user_id'] = 1 ;
        return $this->taskRepository->create($data);
    }
    
    public function getTaskById(int $id)
    {
        return $this->taskRepository->getById($id);
    }

    public function update(array $data, $task)
    {
        return $this->taskRepository->update($data, $task);
    }
}
