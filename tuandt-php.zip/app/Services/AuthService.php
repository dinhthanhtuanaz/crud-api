<?php

namespace App\Services;

use Illuminate\Support\Facades\Auth;

class AuthService
{
    public function signIn($credentinals)
    {
        if (Auth::attempt($credentinals)) {
            return Auth::user();
        }
    }
};
