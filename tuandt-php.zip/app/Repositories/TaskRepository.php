<?php

namespace App\Repositories;

use App\Models\Task;

class TaskRepository
{
    protected $task;

    public function __construct(Task $task)
    {
        $this->task = $task;
    }

    public function getByUserId($title = "")
    {
        $userId = 1;
        return $this->task->where('user_id', $userId)
            ->where('title', 'like', "%$title%")->paginate(config('constants.PER_PAGE'));
    }

    public function create(array $data)
    {
        return $this->task->create($data);
    }

    public function getById(int $id)
    {
        return $this->task->find($id);
    }

    public function update(array $data, $task)
    {
        return $task->update($data);
    }
}
