# TaskManager project

## Manual setup
- Install docker

- Clone source code
```
git clone https://git.hblab.vn/Fresher/tuandt-php.git
cd tuandt-php

docker-compose up -d
composer install
php artisan key:generate
php artisan migrate
composer dump-autoload
php artisan db:seed
```

- Add localhost to hosts file, same bellow
```
127.0.0.1 localhost
```

- Install database and import data by files in folder db

## Commands
- Show container
```
docker-compose ps
```

- Show log
```
docker-compose logs -f php
```
## Usage
- Go to http://fresher.test/, to access system
- Go to http://fresher.test:8080/, to access database
