<?php
return [
    'TASK_STATUS' => [
        0 => 'TODO',
        1 => 'DOING',
        2 => 'DONE'
    ],
    'PER_PAGE' => 10
];
